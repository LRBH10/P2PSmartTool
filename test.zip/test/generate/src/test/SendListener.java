/**
 * 
 * 
 **/
package test;


/**
 **/
public interface SendListener {
   //
   // Methods 
   //

   /**
    * send
    * 
    * @param ev a <code>SendEvent</code> value : event
    **/
   public  void send(SendEvent ev);


}
