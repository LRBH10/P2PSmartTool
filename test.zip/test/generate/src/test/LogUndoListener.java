/**
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 **/
package test;


/**
 **/
public interface LogUndoListener {
   //
   // Methods 
   //

   /**
    * logUndo
    * 
    * @param ev a <code>LogUndoEvent</code> value : event
    **/
   public  void logUndo(LogUndoEvent ev);


}
