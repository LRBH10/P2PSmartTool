/**
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 **/
package test;


/**
 **/
public interface ConnectToListener {
   //
   // Methods 
   //

   /**
    * connectTo
    * 
    * @param ev a <code>ConnectToEvent</code> value : event
    **/
   public  void connectTo(ConnectToEvent ev);


}
