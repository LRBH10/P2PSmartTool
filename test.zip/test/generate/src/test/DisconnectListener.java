/**
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 **/
package test;


/**
 **/
public interface DisconnectListener {
   //
   // Methods 
   //

   /**
    * disconnectOut
    * 
    * @param ev a <code>DisconnectEvent</code> value : event
    **/
   public  void disconnectOut(DisconnectEvent ev);


}
