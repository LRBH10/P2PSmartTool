/**
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 **/
package test;


/**
 **/
public interface ExitListener {
   //
   // Methods 
   //

   /**
    * exit
    * 
    * @param ev a <code>ExitEvent</code> value : event
    **/
   public  void exit(ExitEvent ev);


}
