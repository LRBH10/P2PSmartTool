/**
 * 
 * 
 * null
 * null
 **/
package test;


/**
 **/
public interface TestListener {
   //
   // Methods 
   //

   /**
    * output
    * null
    * @param ev a <code>TestEvent</code> value : event
    **/
   public  void output(TestEvent ev);


}
